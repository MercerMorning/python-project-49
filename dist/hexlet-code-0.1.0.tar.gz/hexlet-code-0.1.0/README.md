### Hexlet tests and linter status:
[![Actions Status](https://github.com/MercerMorning/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/MercerMorning/python-project-49/actions)

<a href="https://codeclimate.com/github/MercerMorning/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c133fc3bc281c6c00fd2/maintainability" /></a>