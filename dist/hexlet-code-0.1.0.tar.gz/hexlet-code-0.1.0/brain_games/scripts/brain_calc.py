#!/usr/bin/env python3
import brain_games.scripts.games.calculator


def main():
    brain_games.scripts.games.calculator.main()


if __name__ == '__main__':
    main()
