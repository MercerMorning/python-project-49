#!/usr/bin/env python3
from colorama import Fore

def welcome_user():
   # name = prompt.string('May I have your name? ')
    print(Fore.RED + 'some red text')
    name = 33
    print(f'Hello, {name}!')

def main():
    welcome_user()

if __name__ == '__main__':
    main()
