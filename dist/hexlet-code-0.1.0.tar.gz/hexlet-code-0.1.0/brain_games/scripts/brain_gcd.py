#!/usr/bin/env python3
import brain_games.scripts.games.gcd


def main():
    brain_games.scripts.games.gcd.main()


if __name__ == '__main__':
    main()
