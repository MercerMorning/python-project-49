#!/usr/bin/env python3
import brain_games.scripts.games.prime


def main():
    brain_games.scripts.games.prime.main()


if __name__ == '__main__':
    main()
