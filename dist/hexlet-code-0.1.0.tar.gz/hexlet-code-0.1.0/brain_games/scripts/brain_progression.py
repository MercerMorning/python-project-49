#!/usr/bin/env python3
import brain_games.scripts.games.progression


def main():
    brain_games.scripts.games.progression.main()


if __name__ == '__main__':
    main()
