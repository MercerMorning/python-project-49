#!/usr/bin/env python3
import brain_games.scripts.games.is_even


def main():
    brain_games.scripts.games.is_even.main()


if __name__ == '__main__':
    main()
