#!/usr/bin/env python3
import brain_games.scripts.cli


def main():
    brain_games.scripts.cli.welcome_user()


if __name__ == '__main__':
    main()
